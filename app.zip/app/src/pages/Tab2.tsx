import React from 'react';
import { IonContent, IonHeader, IonItem, IonLabel, IonList, IonPage, IonTitle, IonToolbar, IonInput, IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonCardContent, IonSearchbar, IonCheckbox } from '@ionic/react';

const Tab2: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Main Page</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonList>
            <IonCard color="dark">
                <IonCardHeader>
                    <IonCardSubtitle>Walking is good for your health and the planet too!</IonCardSubtitle>
                    <IonCardTitle>Where would you like to go?</IonCardTitle>
                </IonCardHeader>
                <IonCardContent>
                    <IonInput placeholder="Enter your destination." color="light"></IonInput>
                </IonCardContent>
                <IonSearchbar animated placeholder="Pick a genre."></IonSearchbar><br></br>
                <IonCheckbox color="dark" /> Random
            </IonCard>
          <IonItem color="primary" routerLink="/tab2/details">
            <IonLabel>
              <h2>Find me some podcasts!</h2>
            </IonLabel>
          </IonItem>
        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default Tab2;